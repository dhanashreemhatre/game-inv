import hat from './hat.png';
import rifle from './rifle.png';
import shirt from './shirt.png';
import sport_shoe from './sport-shoe.png';
import trousers from './trousers.png';
import watch from './wristwatch.png';
import armor from './armor.png';

export { hat, rifle, shirt, sport_shoe, trousers, watch,armor };
