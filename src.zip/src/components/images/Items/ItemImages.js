import apple from "./Apple-Icon.svg";
import banana from "./Banana-Icon.svg";
import firstAidKit from "./First-Aid-Kit-Icon.svg";
import cake from "./Free-Cake-Icons.svg";
import gunBackpack from "./Free-Gun-Icon-Backpack.svg";
import gun from "./Gun-Icon.svg";
import binoculars from "./Gun-Binoculars-Icon.svg";
import handcuffs from "./Gun-Icon-Handcuffs.svg";
import helmet from "./Gun-Icon-Helmet.svg";
import sniper from "./Gun-Icon-Sniper.svg";
import knife from "./Free-Knife-Icon.svg";
import poloShirt from "./Polo-Shirt-Icon.svg";
import shirt from "./Shirt-Icon.svg";

export {apple,banana,firstAidKit,cake,gunBackpack,gun, binoculars, handcuffs, helmet, sniper, knife, poloShirt
    ,shirt
}